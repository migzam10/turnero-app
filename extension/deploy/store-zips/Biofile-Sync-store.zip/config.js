const CONFIG = {
    SERVER_URL: '',
    EXTENSION_SECRET: '',
    // Cadencia de sincronización en segundos. Mínimo permitido 15s (anti rate-limit).
    // Es solo el valor por defecto: cada terminal puede cambiarlo en el engranaje del popup.
    INTERVALO_SEG: 30
};
