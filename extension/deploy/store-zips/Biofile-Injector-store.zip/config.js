const CONFIG = {
    SERVER_URL: '',
    EXTENSION_SECRET: ''
};
