const CONFIG = {
    SERVER_URL: '',
    EXTENSION_SECRET: '',
    INTERVALO_SEG: 30
};
